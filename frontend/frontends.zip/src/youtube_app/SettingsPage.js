import React from 'react';

function SettingsPage() {
  return (
    <div>
      <h1>Settings Page</h1>
      <p>This is where you will configure your API keys and other settings.</p>
    </div>
  );
}

export default SettingsPage;